package UI;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.safari.SafariDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AutomationClass {
	
	public static String browser = "firefox"; //browser
	public static WebDriver driver; //global driver variable
	
	public static void main(String[] args) throws InterruptedException, IOException {
		
		if(browser.equals("chrome"))
		{
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
		}
		else if(browser.equals("firefox"))
		{
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
		}
		else if(browser.equals("safari"))
		{
			WebDriverManager.safaridriver().setup();
			driver = new SafariDriver();
		}
		else if (browser.equals("edge"))
		{
			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver();
		}
		
		
		driver.get("https://www.saucedemo.com/");
		driver.manage().window().maximize();
		//login_page
		driver.findElement(By.xpath("//*[@id=\"user-name\"]")).sendKeys("performance_glitch_user");		
		driver.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys("secret_sauce");	
		driver.findElement(By.xpath("//*[@id=\"login-button\"]")).click();
		//products_page
		driver.findElement(By.xpath("//*[@id=\"item_4_title_link\"]/div")).click();
		//product_page
		driver.findElement(By.xpath("//*[@id=\"add-to-cart-sauce-labs-backpack\"]")).click();
		//shopping_cart
		driver.findElement(By.xpath("//*[@id=\"shopping_cart_container\"]/a")).click();
		driver.findElement(By.xpath("//*[@id=\"checkout\"]")).click();
		//customer_details
		driver.findElement(By.xpath("//*[@id=\"first-name\"]")).sendKeys("Aditya");
		driver.findElement(By.xpath("//*[@id=\"last-name\"]")).sendKeys("Tiwari");
		driver.findElement(By.xpath("//*[@id=\"postal-code\"]")).sendKeys("500081");
		driver.findElement(By.xpath("//*[@id=\"continue\"]")).click();
		//checkout_page
		driver.findElement(By.xpath("//*[@id=\"finish\"]")).click();
		//order_screenshot
		File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scrFile, new File("./Order.png"));
		driver.close();
		driver.quit();
		}
}
//e-commerce website login & navigation 