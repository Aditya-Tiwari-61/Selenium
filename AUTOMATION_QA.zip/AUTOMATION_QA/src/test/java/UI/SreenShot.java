package UI;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.safari.SafariDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class SreenShot {

	public static String browser = "safari"; //browser
	public static WebDriver driver; //global driver variable
	
	public static void main(String[] args) throws IOException, InterruptedException {
		// TODO Auto-generated method stub
			
			if(browser.equals("chrome"))
			{
				WebDriverManager.chromedriver().setup();
				driver = new ChromeDriver();
			}
			else if(browser.equals("firefox"))
			{
				WebDriverManager.firefoxdriver().setup();
				driver = new FirefoxDriver();
			}
			else if(browser.equals("safari"))
			{
				WebDriverManager.safaridriver().setup();
				driver = new SafariDriver();
			}
			else if (browser.equals("edge"))
			{
				WebDriverManager.edgedriver().setup();
				driver = new EdgeDriver();
			}
			
			
			driver.get("https://www.google.com/");
			driver.manage().window().maximize();
			driver.findElement(By.xpath("//*[@id=\"APjFqb\"]")).sendKeys("amazon india" + Keys.ENTER);
			Thread.sleep(1000);
			File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File("./Search.png"));
			driver.close();
			driver.quit();

	}

}
